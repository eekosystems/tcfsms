URL: https://raw.githubusercontent.com/vinaygaba/Ultimate-String-Array-List/master/Country%20telephone%20and%20iso%20codes.xml
