<?php
$plugin_config['de_DE']['title'] = 'Deutsch (Deutschland)';
